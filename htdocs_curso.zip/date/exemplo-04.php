<?php 

date_default_timezone_set("America/Sao_Paulo");

$dt = new DateTime();
echo $dt->format("d/m/Y H:i:s");

 ?>