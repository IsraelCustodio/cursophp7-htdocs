<?php 

date_default_timezone_set("America/Sao_Paulo");

echo date("d/m/Y H:i:s");

echo "<br>";

echo time();

 ?>