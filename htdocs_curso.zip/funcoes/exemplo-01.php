<?php 

function ola() {
	return "Ola Mundo!<br>";	
}

echo ola();
$frase = ola();

echo strlen($frase);

 ?>