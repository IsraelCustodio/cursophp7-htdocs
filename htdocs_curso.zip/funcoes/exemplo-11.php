<?php 

$fn = function($a) {
		var_dump($a);
	};

$fn("Oi");

 ?>