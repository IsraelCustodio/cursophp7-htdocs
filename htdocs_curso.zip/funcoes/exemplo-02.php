<?php 

function salario() {
	return 946.00;
}

echo "Israel recebeu 3 salários: " . (salario() * 3);

 ?>