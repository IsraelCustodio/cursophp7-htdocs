<?php 

var_dump("OK");

function soma($a, $b) {
	return $a + $b;	
}

 ?>