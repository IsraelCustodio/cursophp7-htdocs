<?php 

echo PHP_VERSION;

echo "<br>";

echo DIRECTORY_SEPARATOR;

 ?>