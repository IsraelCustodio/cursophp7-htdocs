<?php 

$a = 35;

$b = 35;

// se $a for maior que $b retorna 1, se for igual retorna 0 se for menor retorna -1
var_dump($a <=> $b);

 ?>