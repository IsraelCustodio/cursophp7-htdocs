<?php 

////////////////Operadores aritiméticos/////////////////////////

$a = 10;
$b = 2;

echo $a + $b;

echo "<br><br>";

echo $a - $b;

echo "<br><br>";

echo $a * $b;

echo "<br><br>";

echo $a / $b;

echo "<br><br>";

//módulo
echo $a % $b;

echo "<br><br>";

//esponenciação
echo $a ** $b;

 ?>