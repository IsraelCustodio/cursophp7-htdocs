<?php 

////////////////Operadores de atribuição/////////////////////////

// operador de atribuição
$nome = "Hcode";

// operador de string
echo $nome . " mais alguma coisa<br><br>";

$nome .= " Treinamentos";

echo $nome;

 ?>