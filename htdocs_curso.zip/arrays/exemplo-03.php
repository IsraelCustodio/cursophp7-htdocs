<?php 

$pessoas = array();

array_push($pessoas, array(
	'nome' => 'Israel',
	'idade' => 25
));

array_push($pessoas, array(
	'nome' => 'Bianca',
	'idade' => 25
));

print_r($pessoas[0]['nome']);

 ?>