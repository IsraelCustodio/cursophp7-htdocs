<?php 

require_once("config.php");

$_SESSION["nome"] = "Hcode";

echo "Sessão iniciada!!!";

 ?>