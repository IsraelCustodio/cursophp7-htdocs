<?php 

$nome = "israel custodio";

$nome = strtoupper($nome);

echo $nome;

$nome = strtolower($nome);

echo "<br>";

echo $nome;

echo "<br>";

echo ucwords($nome);

echo "<br>";

echo ucfirst($nome);

 ?>