<?php 

$nome = "Hcode";

$nome2 = 'Treinamentos';

var_dump($nome, $nome2);

echo "<br><br>ABC $nome<br><br>";

echo 'ABC $nome<br><br>';

 ?>