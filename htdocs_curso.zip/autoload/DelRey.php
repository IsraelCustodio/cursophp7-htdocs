<?php 

class DelRey extends Automovel {
	public function empurrar() {

	}
}

 ?>